// Toggle mobile menu visibility
function toggleMenu() {
    const navLinks = document.querySelector('.nav-links');
    navLinks.classList.toggle('show');
  }
  
  // Registration form validation (basic)
  document.getElementById('registration-form').addEventListener('submit', function(event) {
    event.preventDefault();
  
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
  
    // Password matching validation
    if (password !== confirmPassword) {
      alert("Passwords do not match!");
      return;
    }
  
    const termsCheckbox = document.getElementById('terms');
    if (!termsCheckbox.checked) {
      alert("You must agree to the Terms and Conditions.");
      return;
    }
  
    // Additional form validation (optional)
    const fullName = document.getElementById('full-name').value;
    const email = document.getElementById('email').value;
    const username = document.getElementById('username').value;
  
    if (!fullName || !email || !username) {
      alert("Please fill in all required fields.");
      return;
    }
  
    alert("Registration successful!");
  });
  