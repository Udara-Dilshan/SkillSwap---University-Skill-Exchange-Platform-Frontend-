// Function to format date and time
function formatDate() {
    const now = new Date();
    return now.toLocaleString(); // Format: "MM/DD/YYYY, HH:MM:SS AM/PM"
}

// Function to send a message
function sendMessage() {
    const messageInput = document.getElementById("messageInput");
    const fileInput = document.getElementById("fileInput");
    const messageContainer = document.getElementById("messages");

    // If there's a message to send
    if (messageInput.value.trim() !== "" || fileInput.files.length > 0) {
        const messageText = messageInput.value.trim();
        const file = fileInput.files[0];

        // Create a new message element
        const message = document.createElement("div");
        message.classList.add("message", "sent");

        let contentHTML = `<div class="profile">Y</div>
                           <div class="content">
                             <span class="user">You:</span>
                             <span class="text">${messageText ? messageText : "Sent an attachment"}</span>
                             <span class="time">${formatDate()}</span>
                           </div>`;

        // If a file is selected, add a file attachment message
        if (file) {
            contentHTML = `<div class="profile">Y</div>
                           <div class="content">
                             <span class="user">You:</span>
                             <span class="text">Received file: ${file.name}</span>
                             <span class="time">${formatDate()}</span>
                           </div>`;
        }

        message.innerHTML = contentHTML;
        messageContainer.appendChild(message);

        // Clear the input fields
        messageInput.value = "";
        fileInput.value = "";

        // Scroll to the bottom
        messageContainer.scrollTop = messageContainer.scrollHeight;

        // Simulate a response after 1 second
        setTimeout(() => {
            const responseMessage = document.createElement("div");
            responseMessage.classList.add("message");

            responseMessage.innerHTML = `<div class="profile">A</div>
                                         <div class="content">
                                           <span class="user">Alex:</span>
                                           <span class="text">Hello! How are you?</span>
                                           <span class="time">${formatDate()}</span>
                                         </div>`;
            messageContainer.appendChild(responseMessage);
            messageContainer.scrollTop = messageContainer.scrollHeight;
        }, 1000);
    }
}

// Toggle the mobile menu
function toggleMenu() {
    const navLinks = document.querySelector('.nav-links');
    navLinks.classList.toggle('show');
}
