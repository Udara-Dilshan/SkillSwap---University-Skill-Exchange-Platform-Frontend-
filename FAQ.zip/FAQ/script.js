// Toggle menu for mobile view
function toggleMenu() {
    const navLinks = document.querySelector('.nav-links');
    navLinks.classList.toggle('show');
  }
  
  // Toggle FAQ answers
  document.querySelectorAll('.faq-question').forEach(question => {
    question.addEventListener('click', () => {
      const faqItem = question.parentElement;
      const isActive = faqItem.classList.contains('active');
  
      // Close all answers
      document.querySelectorAll('.faq-item').forEach(item => item.classList.remove('active'));
  
      // Toggle the clicked one
      if (!isActive) {
        faqItem.classList.add('active');
      }
    });
  });
  