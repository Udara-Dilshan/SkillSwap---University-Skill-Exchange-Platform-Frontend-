function toggleMenu() {
    const navLinks = document.querySelector('.nav-links');
    navLinks.classList.toggle('show');
  }
  
  function cancelForm() {
    document.getElementById('skillForm').reset();
  }
  